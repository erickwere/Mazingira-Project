-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2018 at 10:36 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mazingira_connect`
--

-- --------------------------------------------------------

--
-- Table structure for table `enterprise_details`
--

CREATE TABLE `enterprise_details` (
  `Enterprise_ID` int(11) NOT NULL,
  `Enterprise_Name` varchar(30) DEFAULT NULL,
  `Location` varchar(30) DEFAULT NULL,
  `Rescue_Team_ID` int(11) DEFAULT NULL,
  `Rescue_Team_Name` varchar(30) DEFAULT NULL,
  `Telephone_No` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loyalty_points`
--

CREATE TABLE `loyalty_points` (
  `User_ID` int(11) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `No_Of_Loyalty_Points` int(11) DEFAULT NULL,
  `Redeemed_Points` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(30) NOT NULL,
  `Enterprise_Name` varchar(30) DEFAULT NULL,
  `Rescue_Team_ID` int(11) DEFAULT NULL,
  `Rescue_Team_Name` varchar(30) DEFAULT NULL,
  `Enterprise_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `projects_reports`
-- (See below for the actual view)
--
CREATE TABLE `projects_reports` (
`Project_ID` int(11)
,`Project_Name` varchar(30)
,`Enterprise_Name` varchar(30)
,`Rescue_Team_ID` int(11)
,`Rescue_Team_Name` varchar(30)
,`Enterprise_ID` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `rescue_team`
--

CREATE TABLE `rescue_team` (
  `Rescue_Team_ID` int(11) NOT NULL,
  `Rescue_Team_Name` varchar(30) NOT NULL,
  `Enterprise_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rescue_team_projects`
--

CREATE TABLE `rescue_team_projects` (
  `Project_ID` int(11) NOT NULL,
  `Rescue_Team_ID` int(11) NOT NULL,
  `Rescue_Team_Name` varchar(30) NOT NULL,
  `Completed_Projects` int(11) DEFAULT NULL,
  `Assigned_Projects` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `statusreport`
-- (See below for the actual view)
--
CREATE TABLE `statusreport` (
`Enterprise_ID` int(11)
,`Enterprise_Name` varchar(30)
,`No_Of_Projects` int(11)
,`Running_Projects` int(11)
,`Pending_Projects` int(11)
,`Project_Name` varchar(50)
,`Location` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `status_reports`
--

CREATE TABLE `status_reports` (
  `Enterprise_ID` int(11) NOT NULL,
  `Enterprise_Name` varchar(30) DEFAULT NULL,
  `No_Of_Projects` int(11) DEFAULT NULL,
  `Running_Projects` int(11) DEFAULT NULL,
  `Pending_Projects` int(11) DEFAULT NULL,
  `Project_Name` varchar(50) DEFAULT NULL,
  `Location` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `team_projects`
-- (See below for the actual view)
--
CREATE TABLE `team_projects` (
`Project_ID` int(11)
,`Rescue_Team_ID` int(11)
,`Rescue_Team_Name` varchar(30)
,`Completed_Projects` int(11)
,`Assigned_Projects` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(30) DEFAULT NULL,
  `Last_Name` varchar(30) DEFAULT NULL,
  `Username` varchar(25) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Address` varchar(40) DEFAULT NULL,
  `Loyalty_Points` int(11) DEFAULT NULL,
  `Phone_No` int(10) DEFAULT NULL,
  `Projects_ID` int(11) NOT NULL,
  `Images_Uploaded` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure for view `projects_reports`
--
DROP TABLE IF EXISTS `projects_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`Projects`@`%` SQL SECURITY DEFINER VIEW `projects_reports`  AS  select `projects`.`Project_ID` AS `Project_ID`,`projects`.`Project_Name` AS `Project_Name`,`projects`.`Enterprise_Name` AS `Enterprise_Name`,`projects`.`Rescue_Team_ID` AS `Rescue_Team_ID`,`projects`.`Rescue_Team_Name` AS `Rescue_Team_Name`,`projects`.`Enterprise_ID` AS `Enterprise_ID` from `projects` ;

-- --------------------------------------------------------

--
-- Structure for view `statusreport`
--
DROP TABLE IF EXISTS `statusreport`;

CREATE ALGORITHM=UNDEFINED DEFINER=`StatusReport`@`%` SQL SECURITY DEFINER VIEW `statusreport`  AS  select `status_reports`.`Enterprise_ID` AS `Enterprise_ID`,`status_reports`.`Enterprise_Name` AS `Enterprise_Name`,`status_reports`.`No_Of_Projects` AS `No_Of_Projects`,`status_reports`.`Running_Projects` AS `Running_Projects`,`status_reports`.`Pending_Projects` AS `Pending_Projects`,`status_reports`.`Project_Name` AS `Project_Name`,`status_reports`.`Location` AS `Location` from `status_reports` ;

-- --------------------------------------------------------

--
-- Structure for view `team_projects`
--
DROP TABLE IF EXISTS `team_projects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`Team_Projects`@`%` SQL SECURITY DEFINER VIEW `team_projects`  AS  select `rescue_team_projects`.`Project_ID` AS `Project_ID`,`rescue_team_projects`.`Rescue_Team_ID` AS `Rescue_Team_ID`,`rescue_team_projects`.`Rescue_Team_Name` AS `Rescue_Team_Name`,`rescue_team_projects`.`Completed_Projects` AS `Completed_Projects`,`rescue_team_projects`.`Assigned_Projects` AS `Assigned_Projects` from `rescue_team_projects` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enterprise_details`
--
ALTER TABLE `enterprise_details`
  ADD PRIMARY KEY (`Enterprise_ID`);

--
-- Indexes for table `loyalty_points`
--
ALTER TABLE `loyalty_points`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`Project_ID`),
  ADD KEY `Enterprise_ID` (`Enterprise_ID`);

--
-- Indexes for table `rescue_team`
--
ALTER TABLE `rescue_team`
  ADD PRIMARY KEY (`Rescue_Team_ID`),
  ADD KEY `Enterprise_ID` (`Enterprise_ID`);

--
-- Indexes for table `rescue_team_projects`
--
ALTER TABLE `rescue_team_projects`
  ADD PRIMARY KEY (`Project_ID`),
  ADD KEY `Rescue_Team_ID` (`Rescue_Team_ID`);

--
-- Indexes for table `status_reports`
--
ALTER TABLE `status_reports`
  ADD PRIMARY KEY (`Enterprise_ID`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enterprise_details`
--
ALTER TABLE `enterprise_details`
  MODIFY `Enterprise_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`Enterprise_ID`) REFERENCES `enterprise_details` (`Enterprise_ID`);

--
-- Constraints for table `rescue_team`
--
ALTER TABLE `rescue_team`
  ADD CONSTRAINT `rescue_team_ibfk_1` FOREIGN KEY (`Enterprise_ID`) REFERENCES `enterprise_details` (`Enterprise_ID`);

--
-- Constraints for table `rescue_team_projects`
--
ALTER TABLE `rescue_team_projects`
  ADD CONSTRAINT `rescue_team_projects_ibfk_1` FOREIGN KEY (`Rescue_Team_ID`) REFERENCES `rescue_team` (`Rescue_Team_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
