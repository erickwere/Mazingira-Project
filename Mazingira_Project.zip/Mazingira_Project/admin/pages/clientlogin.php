<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mazingira_connect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

	//Sanitize the POST values
	$login = $_POST['User_ID'];
	$password = $_POST['Password'];
	

$sql = "SELECT * FROM user_details WHERE User_ID='$login' AND Password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
$_SESSION['User_ID'] =$_POST['User_ID'];
    
    while($row = $result->fetch_assoc()) {
        echo "<script type='text/javascript'>
					window.location='index.html';
				</script>";
    }
} else {
    echo "<script type='text/javascript'>alert('Successful Login');
					window.location='index.html';
						</script>";
}
$conn->close();
?> 