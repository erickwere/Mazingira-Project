function myMap() {
	var mapCanvas = document.getElementById("map");
	var mapOptions = {
		center : new
		google.maps.LatLng(1.2921,36.8219), zoom : 10
		
	};
	var map = new
	google.maps.Map(mapCanvas,mapOptions);

	
}	


<script 
src="https://maps.googleapis.com/maps/api/js?key=Your_key&callback=myMap">
</Script>
