<?php
$target_dir = "uploads/";
$target_file = $target_dir
.
basename($_FILES["ImagetoUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(path info($target_file,PATHINFO_EXTENSION));

if (isset($_POST["submit"]))
{
	
	$check =
	getimagesize($_FILES["ImagetoUpload"]["tmp_name"]);
	if ($check !==false) {
		
		echo "File is an Image -". $check["mime"]
		.".";
		$uploadOk = 1;
		
	}  else {
		echo "File is not an Image.";
		
		$uploadOk =0;
	}
	
}







?>