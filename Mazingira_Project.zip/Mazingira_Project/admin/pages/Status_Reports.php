<?php
$con=mysqli_connect ("localhost","my user","my password","my_db");
//check connection
if (mysqli_connect_errno())
{
	echo "Failed to Connect to MySQL :" .
	mysqli_connect_error();
}
$sql= "Select Enterprise_Name,Enterprise_ID,No_of_Projects,Completed_Projects,Running_Projects,Pending_Projects FROM Status_Reports ORDER BY Enterprise_ID";
$result=mysqli_query($con,$sql);

mysqli_close($con);















?>