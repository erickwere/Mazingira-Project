 function view_all_info() {
            var CID = document.getElementById("clientID").value;
            var Assign = document.getElementById("assignTo").value;
            var TaskType = document.getElementById("taskType").value;
            var taskPriority = document.getElementById("priority").value;
            var myDes = document.getElementsByName("des")[0].value;
            var url = window.location.pathname;
            var filename = url.substring(url.lastIndexOf('/')+1);

            if(CID){
                if(Assign){
                    if(TaskType){
                        if(taskPriority){
                        }
                        else{
                            alert('Please Enter Task Level')
                        }
                    }
                    else{
                        alert('Please Enter Task Type')
                    }
                }
                else{
                    alert('Please Assign Task To Someone')
                }
            }
            else{
                alert('Please Enter Client ID')
            }

        if(CID && Assign && TaskType && taskPriority) {

            document.getElementById("taskDetails_info").style.display = "block";
            document.getElementById("taskAssignInfo").style.display = "none";
            document.getElementById("client_ID").innerHTML = CID;
            document.getElementById("assign_to").innerHTML = Assign;
            document.getElementById("task_type").innerHTML = TaskType;
            document.getElementById("task_priority").innerHTML = taskPriority;
            document.getElementById("task_des").innerHTML = myDes;
            document.getElementById("file").innerHTML = filename;
        }
        }
        function backHome(){
            document.getElementById("taskAssignInfo").style.display = "block";
            location.reload();
        }